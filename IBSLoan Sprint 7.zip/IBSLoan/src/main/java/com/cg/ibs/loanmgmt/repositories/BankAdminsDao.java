package com.cg.ibs.loanmgmt.repositories;

import java.util.List;

import com.cg.ibs.loanmgmt.models.BankAdmins;

public interface BankAdminsDao {
	BankAdmins getAdminByUserId(String userId);

	List<BankAdmins> getRegisteredBankAdmins();
}
