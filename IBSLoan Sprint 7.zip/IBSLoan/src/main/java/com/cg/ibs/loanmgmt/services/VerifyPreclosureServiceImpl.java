package com.cg.ibs.loanmgmt.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.cg.ibs.loanmgmt.models.BankAdmins;
import com.cg.ibs.loanmgmt.models.LoanMaster;
import com.cg.ibs.loanmgmt.repositories.LoanMasterDao;

public class VerifyPreclosureServiceImpl implements VerifyPreclosureService {
	@Autowired
	private LoanMasterDao loanMasterDao;

	@Override
	public List<LoanMaster> getSentForVerificationPreclosure(BankAdmins loggedInBankAdmin) {
		
		return loanMasterDao.getSentForVerificationPreclosure(loggedInBankAdmin);
	}

	@Override
	public LoanMaster updatePreclosurePostVerify(LoanMaster globalLoanMaster) {
		return null;
	}

	@Override
	public LoanMaster updatePreclosurePostDenial(LoanMaster globalLoanMaster) {
		return null;
	}

}
