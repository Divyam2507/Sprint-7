package com.cg.ibs.loanmgmt.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.ibs.loanmgmt.services.BankAdminService;
import com.cg.ibs.loanmgmt.services.CustomerService;

@Controller
public class DefaultController {
	@Autowired
	private CustomerService customerService;
	@Autowired
	private BankAdminService bankAdminService;

	@RequestMapping(method = RequestMethod.GET, value = { "/","/logOut"})
	public String showHome() {
		return "homePage";
	}
	@RequestMapping(method = RequestMethod.GET, value = { "/login"})
	public String showLogin() {
		return "loginPage";
	}
	@RequestMapping(method = RequestMethod.POST, value = "/loginVerify")
	public String loginRole(@RequestParam("role") String role, @RequestParam("userId") String userId,
			@RequestParam("password") String password) {
		String viewName = "";

		switch (role) {
		case "CUSTOMER":
			if (customerService.verifyCustomerLogin(userId, password)) {
				viewName = "redirect:/customer?userId=" + userId;
			} else {
				viewName = "redirect:/failLogin";
			}
			break;
		case "BANK_ADMIN":
			if (bankAdminService.verifyBankLogin(userId, password)) {
				viewName = "redirect:/bankAdmin?userId=" + userId;
			}else {
				viewName = "redirect:/failLogin";
			}
			break;
		}

		return viewName;
	}
	
	@RequestMapping(method = RequestMethod.GET, value = "/failLogin")
	public ModelAndView loginRole() {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("message1","Invalid Credentials!");
		modelAndView.setViewName("errorLoginPage");
		return modelAndView;
	}

}
