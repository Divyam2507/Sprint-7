package com.cg.ibs.loanmgmt.services;

import java.math.BigInteger;
import java.util.List;

import javax.persistence.EntityTransaction;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ibs.loanmgmt.models.CustomerBean;
import com.cg.ibs.loanmgmt.models.LoanMaster;
import com.cg.ibs.loanmgmt.models.TransactionBean;
import com.cg.ibs.loanmgmt.repositories.LoanMasterDao;
import com.cg.ibs.loanmgmt.repositories.TransactionDao;

@Service
public class PayEmiServiceImpl implements PayEmiService {
	@Autowired
	private LoanMasterDao loanMasterDao;
	@Autowired
	private TransactionDao transactionDao;

	@Override
	public List<LoanMaster> getApprovedLoanListByUci(CustomerBean customer) {
		return loanMasterDao.getApprovedLoanListByUci(customer);
	}

	@Override
	public LoanMaster getLoanByLoanNum(BigInteger loanAccountNumber) {
		return loanMasterDao.getLoanByLoanNumber(loanAccountNumber);
	}

	@Override
	@Transactional
	public LoanMaster updateLoanPostEmi(LoanMaster globalLoanMaster) {
		return loanMasterDao.updateEmiDao(globalLoanMaster);
	}

	@Override
	@Transactional
	public TransactionBean createDebitTransaction(LoanMaster globalLoanMaster) {
		TransactionBean transaction = new TransactionBean();
		transaction = transactionDao.createDebitTransaction(globalLoanMaster, transaction);
		return transaction;
	}

	@Override
	@Transactional
	public TransactionBean createCreditTransaction(LoanMaster globalLoanMaster) {
		TransactionBean transaction = new TransactionBean();
		transaction = transactionDao.createCreditTransaction(globalLoanMaster, transaction);
		return transaction;
	}

}
